# Pakistani Notes Counter > 2023-12-26 12:33pm
https://universe.roboflow.com/currency-detection-dodpy/pakistani-notes-counter

Provided by a Roboflow user
License: CC BY 4.0

